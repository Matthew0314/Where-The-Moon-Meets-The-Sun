using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using UnityEngine.EventSystems;
using System.Linq;
using TMPro;



public class BattleStartMenu : MonoBehaviour
{
    private Button[,] buttons;
    private string[,] actions;
    [SerializeField] Button unitButton;
    [SerializeField] Button mapButton;
    [SerializeField] Button startButton;
    [SerializeField] Button exitButton;
    [SerializeField] GameObject battleStartMenu;
    [SerializeField] GameObject UnitSelectButton;
    [SerializeField] GameObject UnitSelectBox;
    [SerializeField] RectTransform content;
    [SerializeField] ScrollRect scrollRect;
    [SerializeField] TextMeshProUGUI unitNumber;
    private List<UnitStats> playableRoster = new List<UnitStats>();

    private float sensitivity = 0.5f;
    private Vector2 moveInput;
    [SerializeField] PlayerInput playerInput;
    private bool inStartMenu = false;
    private bool inMapMenu = false;
    [SerializeField] PlayerGridMovement playerGridMovement;
    private MapManager _currentMap;

    private List<Button> unitButtons = new List<Button>();
    private List<UnitManager> unitList = new List<UnitManager>();
    private List<string> units = new List<string>();
    List<UnitStats> combinedList = new List<UnitStats>();
    private int selectedIndex = 0;
    private int buttonsPerRow = 2;


    [SerializeField] private GameObject InfoTextData;
    [SerializeField] private Image expBar;
    [SerializeField] private GameObject unitItemBar;
    // [SerializeField] UnityEngine.UI.Slider expBar; 
    private List<GameObject> unitItemBarsList = new List<GameObject>();

    void Awake()
    {
        // playerGridMovement = GameObject.Find("Player").GetComponent<PlayerGridMovement>();
        _currentMap = GameObject.Find("GridManager").GetComponent<MapManager>();

        if (unitButton == null || mapButton == null || startButton == null || exitButton == null)
        {
            Debug.LogError("One or more buttons are not assigned in the inspector.");
            return;
        }

        actions = new string[2, 2]
        {
            { "Units", "Map" },
            { "Start" , "Exit" }
        };

        buttons = new Button[2, 2]
        {
            { unitButton, mapButton },
            { startButton, exitButton }
        };
    }

    void Update()
    {
        moveInput = playerInput.actions["Move"].ReadValue<Vector2>();
    }

    public IEnumerator StartMenu()
    {
        battleStartMenu.SetActive(true);
        inStartMenu = true;

        bool axisInUse = false;
        int currentRow = 0, currentCol = 0;
        int rowCount = buttons.GetLength(0);
        int colCount = buttons.GetLength(1);

        // Select initial button
        buttons[currentRow, currentCol].Select();

        while (true)
        {
            float vertical = moveInput.y;
            float horizontal = moveInput.x;

            if (!axisInUse)
            {
                currentRow = (currentRow - Mathf.RoundToInt(vertical) + rowCount) % rowCount;
                currentCol = (currentCol + Mathf.RoundToInt(horizontal) + colCount) % colCount;

                if (vertical != 0 || horizontal != 0)
                {
                    axisInUse = true;
                    buttons[currentRow, currentCol].Select();
                }
            }

            if (Mathf.Abs(vertical) < sensitivity && Mathf.Abs(horizontal) < sensitivity)
                axisInUse = false;

            if (playerInput.actions["Select"].WasPressedThisFrame())
            {
                string selectedAction = actions[currentRow, currentCol];

                switch (selectedAction)
                {
                    case "Start":
                        break;
                    case "Map":
                        yield return StartCoroutine(InMapMenu());
                        break;
                    case "Units":
                        yield return StartCoroutine(UnitSelect());
                        buttons[currentRow, currentCol].Select();
                        break;
                }

                if (selectedAction == "Start")
                    break;
            }

            yield return null;
        }

        battleStartMenu.SetActive(false);
        inStartMenu = false;
    }


    private IEnumerator InMapMenu()
    {
        _currentMap.InitStartTiles();
        battleStartMenu.SetActive(false);
        inMapMenu = true;
        while (true)
        {
            if (playerInput.actions["Back"].WasPressedThisFrame() && playerGridMovement.BackToStartMenu())
            {
                battleStartMenu.SetActive(true);
                inMapMenu = false;
                _currentMap.DestroyStartTiles();

                yield break;
            }

            yield return null;
        }
    }


    public bool GetInStartMenu() => inStartMenu;
    public bool GetInMapMenu() => inMapMenu;

    private IEnumerator UnitSelect()
    {
        BuildUnitSelectMenu();

        if (unitButtons.Count == 0) yield break;

        selectedIndex = 0;
        SelectUnit(selectedIndex);

        unitNumber.text = $"{_currentMap.GetMapUnits().Count}/{_currentMap.GetPlayerStartPositions().Length}";


        float inputCooldown = 0.2f;
        float lastInputTime = -inputCooldown;

        while (true)
        {
            // Handle navigation
            if (Time.unscaledTime - lastInputTime > inputCooldown)
            {
                Vector2 input = moveInput;
                int delta = 0;

                if (input.x > 0.5f) delta = 1;
                else if (input.x < -0.5f) delta = -1;
                else if (input.y > 0.5f) delta = -buttonsPerRow;
                else if (input.y < -0.5f) delta = buttonsPerRow;

                if (delta != 0)
                {
                    CycleSelection(delta);
                    lastInputTime = Time.unscaledTime;
                }
            }

            // Handle selection
            if (playerInput.actions["Select"].WasPressedThisFrame())
            {
                UnitStats unit = UnitRosterManager.GetPlayableUnit(units[selectedIndex]);
                List<string> cantUse = _currentMap.GetRequiredUnits().Concat(_currentMap.GetForbiddenUnits()).ToList();

                if (cantUse.Contains(unit.UnitName))
                {
                    yield return null;
                    continue;
                }

                List<UnitManager> mapUnits = _currentMap.GetMapUnits();
                UnitManager matchUnit = mapUnits.FirstOrDefault(u => u.GetUnitName() == unit.UnitName);

                if (matchUnit != null)
                {
                    _currentMap.DespawnUnit(matchUnit);
                    ChangeTextColor(unitButtons[selectedIndex], "default", matchUnit.GetName());
                }
                else if (mapUnits.Count < _currentMap.GetPlayerStartPositions().Length)
                {
                    _currentMap.SpawnUnit(unit, _currentMap.FindNextStartPosition());
                    ChangeTextColor(unitButtons[selectedIndex], "blue", unit.Name);
                }

                yield return null;
            }

            // Handle cancel
            if (playerInput.actions["Back"].WasPressedThisFrame())
            {
                ClearUnitSelect();
                yield break;
            }

            yield return null;
        }
    }

    private void ClearUnitSelect()
    {
        foreach (var but in unitButtons) Destroy(but.gameObject);
        unitButtons.Clear();
        unitList.Clear();
        units.Clear();
        combinedList.Clear();
        UnitSelectBox.SetActive(false);
    }

    private void SelectUnit(int index)
    {
        selectedIndex = index;
        unitButtons[selectedIndex].Select();
        ScrollToButton(unitButtons[selectedIndex].GetComponent<RectTransform>());
        UpdateUnitInfo(combinedList[selectedIndex]);
    }

    private void CycleSelection(int delta)
    {
        int newIndex = Mathf.Clamp(selectedIndex + delta, 0, unitButtons.Count - 1);
        SelectUnit(newIndex);
    }

    private void ChangeTextColor(Button button, string color, string name)
    {
        TMPro.TextMeshProUGUI[] texts = button.GetComponentsInChildren<TMPro.TextMeshProUGUI>();
        string colorTag = color switch
        {
            "green" => "<color=#228B22>",
            "blue" => "<color=#0000FF>",
            "red" => "<color=#FF0000>",
            _ => ""
        };

        foreach (var text in texts)
        {
            if (text.name.ToLower().Contains("name"))
                text.text = colorTag + name + (colorTag != "" ? "</color>" : "");
        }

        unitNumber.text = $"{_currentMap.GetMapUnits().Count}/{_currentMap.GetPlayerStartPositions().Length}";
    }

    private void ScrollToButton(RectTransform targetButton)
    {
        Canvas.ForceUpdateCanvases();

        float contentHeight = content.rect.height;
        float viewportHeight = scrollRect.viewport.rect.height;

        // Center the button in the viewport
        float buttonCenterY = -targetButton.localPosition.y + targetButton.rect.height / 2f;
        float scrollY = Mathf.Clamp(buttonCenterY - viewportHeight / 1.25f, 0, contentHeight - viewportHeight);

        scrollRect.verticalNormalizedPosition = 1f - Mathf.Clamp01(scrollY / (contentHeight - viewportHeight));
    }

    public void UpdateUnitInfo(UnitStats stats)
    {
        // Update basic info
        foreach (var text in InfoTextData.GetComponentsInChildren<TMPro.TextMeshProUGUI>())
        {
            string lname = text.name.ToLower();
            text.text = lname switch
            {
                var n when n.Contains("level") => stats.Level.ToString(),
                var n when n.Contains("name") => stats.Name,
                var n when n.Contains("exp") => stats.Experience.ToString(),
                var n when n.Contains("health") => $"{stats.CurrentHealth}/{stats.Health}",
                var n when n.Contains("class") => stats.UnitClass,
                _ => text.text
            };
        }
        if (expBar != null )
        {
            expBar.fillAmount = Mathf.Clamp01((float)stats.Experience / 100.0f);
        } 

        // Clear old item bars
        foreach (var g in unitItemBarsList) Destroy(g);
        unitItemBarsList.Clear();

        int count = 0;
        int offset = -52;

        // Combine weapons and items for display
        foreach (var entry in stats.GetWeaponsList().Cast<object>().Concat(stats.GetItems()))
        {
            GameObject bar = Instantiate(unitItemBar, InfoTextData.transform, false);
            bar.transform.localPosition += new Vector3(0, count * offset, 0);

            foreach (var text in bar.GetComponentsInChildren<TMPro.TextMeshProUGUI>())
            {
                string lname = text.name.ToLower();

                if (lname.Contains("item"))
                    text.text = entry switch
                    {
                        Weapon w => w.WeaponName + (stats.GetPrimaryWeapon() == w ? " (e)" : ""),
                        Item i => i.Name,
                        _ => ""
                    };
                else if (lname.Contains("uses"))
                    text.text = entry switch
                    {
                        Weapon w => $"{w.Uses}/{w.MaxUses}",
                        Item i => $"{i.Uses}/{i.MaxUses}",
                        _ => ""
                    };
            }

            unitItemBarsList.Add(bar);
            count++;
        }
    }

    private void BuildUnitSelectMenu()
    {
        UnitSelectBox.SetActive(true);


        int buttonsPerRow = 2;
        float xSpacing = 450f;
        float ySpacing = 100f;

        Vector2 startPos = new Vector2(-225f, 400f);

        List<UnitStats> playableRoster = UnitRosterManager.GetPlayableUnits(); // ✅ Still UnitStats

        List<string> requiredUnits = _currentMap.GetRequiredUnits();
        List<UnitManager> mapUnits = _currentMap.GetMapUnits(); // ✅ UnitManagers
        List<string> forbiddenUnits = _currentMap.GetForbiddenUnits();

        // Split into groups using UnitName comparisons
        var requiredList = playableRoster
            .Where(unit => requiredUnits.Contains(unit.UnitName))
            .ToList();

        var mapUnitsOnlyList = playableRoster
            .Where(unit => !requiredUnits.Contains(unit.UnitName)
                        && !forbiddenUnits.Contains(unit.UnitName)
                        && mapUnits.Any(mu => mu.GetUnitName() == unit.UnitName))
            .ToList();

        var restList = playableRoster
            .Where(unit => !requiredUnits.Contains(unit.UnitName)
                        && !forbiddenUnits.Contains(unit.UnitName)
                        && !mapUnits.Any(mu => mu.GetUnitName() == unit.UnitName))
            .ToList();

        var forbiddenList = playableRoster
            .Where(unit => forbiddenUnits.Contains(unit.UnitName))
            .ToList();

        // Combine lists in order
        combinedList = requiredList
            .Concat(mapUnitsOnlyList)
            .Concat(restList)
            .Concat(forbiddenList)
            .ToList();

        foreach (Button but in unitButtons)
        {
            Destroy(but.gameObject);
        }
        unitButtons.Clear();
        unitList.Clear();

        for (int i = 0; i < combinedList.Count; i++)
        {
            int row = i / buttonsPerRow;
            int col = i % buttonsPerRow;

            float x = startPos.x + (col * xSpacing);
            float y = startPos.y - (row * ySpacing);

            GameObject button = Instantiate(UnitSelectButton, content);
            // RectTransform rect = button.GetComponent<RectTransform>();
            // rect.anchoredPosition = new Vector2(x, y);

            UnitStats stats = combinedList[i];
            TMPro.TextMeshProUGUI[] texts = button.GetComponentsInChildren<TMPro.TextMeshProUGUI>();


            foreach (var text in texts)
            {
                if (text.name.ToLower().Contains("name"))
                {
                    string color = "";

                    if (requiredUnits.Contains(stats.UnitName))
                    {
                        color = "<color=#228B22>"; // Green
                        UnitManager matchingUnit = mapUnits.Find(u => u.GetUnitName() == stats.UnitName);
                        unitList.Add(matchingUnit);
                    }
                    else if (mapUnits.Any(mu => mu.GetUnitName() == stats.UnitName)
                        && !requiredUnits.Contains(stats.UnitName)
                        && !forbiddenUnits.Contains(stats.UnitName))
                    {
                        color = "<color=#0000FF>"; // Blue

                        UnitManager matchingUnit = mapUnits.Find(u => u.GetUnitName() == stats.UnitName);
                        unitList.Add(matchingUnit);
                    }

                    else if (forbiddenUnits.Contains(stats.UnitName))
                        color = "<color=#FF0000>"; // Red
                    else
                        color = ""; // Default

                    text.text = color + stats.Name + (color != "" ? "</color>" : "");
                }
                else if (text.name.ToLower().Contains("health"))
                {
                    text.text = $"{stats.CurrentHealth}/{stats.Health}";
                }
            }

            Button btn = button.GetComponent<Button>();
            unitButtons.Add(btn);
            // unitList.Add()
            units.Add(stats.UnitName);

        }
    }







}
